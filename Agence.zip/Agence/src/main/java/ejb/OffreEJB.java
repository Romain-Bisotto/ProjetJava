package ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import model.Offre;

@Stateless
public class OffreEJB {

	@PersistenceUnit
	private EntityManagerFactory emf;

	public Offre findOffreById(Long id) {
		EntityManager em = emf.createEntityManager();
		Offre Offre = em.find(Offre.class, id);
		em.close();
		return Offre;
	}

	public Offre createOffre(Offre Offre) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(Offre);
		em.getTransaction().commit();
		em.close();
		return Offre;
	}

	public void updateOffre(Offre Offre) {
		// Récupération de l'EntityManager
		EntityManager em = emf.createEntityManager();
		// Début de la transaction
		em.getTransaction().begin();
		// Mise à jour de l'objet Offre dans la base de données
		em.merge(Offre);
		// Fin de la transaction
		em.getTransaction().commit();
		// Fermeture de l'EntityManager
		em.close();
	}

	public List<Offre> findAllOffres() {
		EntityManager em = emf.createEntityManager();
		TypedQuery<Offre> query = em.createQuery("SELECT b FROM Offre b", Offre.class);
		List<Offre> Offres = query.getResultList();
		em.close();
		return Offres;
	}

	public void deleteOffre(Long id) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Offre Offre = em.find(Offre.class, id);
		em.remove(Offre);
		em.getTransaction().commit();
		em.close();
	}

}
