package model;

public class Offre {

	private int id;
	private String dateCreation;
	private int prix;
	private String description;
	private String mailProprietaire;
	// private String photo;

	public Offre(int id, String dateCreation, int prix, String description, String mailProprietaire) {
		this.setId(id);
		this.setDateCreation(dateCreation);
		this.setPrix(prix);
		this.setDescription(description);
		this.setMailProprietaire(mailProprietaire);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(String dateCreation) {
		this.dateCreation = dateCreation;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrix() {
		return prix;
	}

	public void setPrix(int prix) {
		this.prix = prix;
	}

	public String getMailProprietaire() {
		return mailProprietaire;
	}

	public void setMailProprietaire(String mailProprietaire) {
		this.mailProprietaire = mailProprietaire;
	}

}
