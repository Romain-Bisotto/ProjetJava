package servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ejb.TypeUtilisateurEJB;
import ejb.UtilisateurEJB;
import model.Utilisateur;

@WebServlet("/UtilisateurServlet")
public class UtilisateurServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EJB
    private UtilisateurEJB utilisateurEJB;

    @EJB
    private TypeUtilisateurEJB typeUtilisateurEJB;
    
    public UtilisateurServlet() {
    	super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("tototi");
        HttpSession session = request.getSession();
        Utilisateur utilisateur = (Utilisateur) session.getAttribute("utilisateur");
        if (utilisateur != null) {
            // L'utilisateur est déjà connecté, on le redirige vers la page d'accueil
        	request.getRequestDispatcher("/utilisateur.jsp").forward(request, response);
            return;
        }
        
        
        // Affiche le formulaire de connexion
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        System.out.println(action);
        if ("login".equals(action)) {
        	
        	//java.util.logging.Logger("toto");
            String email = request.getParameter("email");
            String mdp = request.getParameter("mdp");
            Utilisateur utilisateur = utilisateurEJB.findUtilisateurByEmail(email);
            if (utilisateur != null && utilisateur.getMdp().equals(mdp)) {
                // L'utilisateur a saisi les bons identifiants, on le connecte
                HttpSession session = request.getSession();
                session.setAttribute("utilisateur", utilisateur);
                getServletContext().getRequestDispatcher("/utilisateur.jsp").forward(request, response);
                return;
            }

            // L'utilisateur a saisi de mauvais identifiants, on affiche un message d'erreur
            request.setAttribute("error", "Email ou mot de passe incorrect");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        } else if ("logout".equals(action)) {
            HttpSession session = request.getSession();
            session.invalidate();
            request.getRequestDispatcher("/utilisateur.jsp").forward(request, response);
        } else {
            // Action inconnue, on affiche une erreur
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
        }
    }

}

