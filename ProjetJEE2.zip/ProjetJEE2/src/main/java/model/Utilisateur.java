package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the utilisateur database table.
 * 
 */
@Entity
@NamedQuery(name="Utilisateur.findAll", query="SELECT u FROM Utilisateur u")
public class Utilisateur implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int ID_Utilisateur;

	private String adresse;

	private String email;

	private int IDTypeUtilisateur;

	private String mdp;

	private String nom;

	private String numero;

	private String prenom;

	private String salt;

	public Utilisateur() {
	}

	public int getID_Utilisateur() {
		return this.ID_Utilisateur;
	}

	public void setID_Utilisateur(int ID_Utilisateur) {
		this.ID_Utilisateur = ID_Utilisateur;
	}

	public String getAdresse() {
		return this.adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getIDTypeUtilisateur() {
		return this.IDTypeUtilisateur;
	}

	public void setIDTypeUtilisateur(int IDTypeUtilisateur) {
		this.IDTypeUtilisateur = IDTypeUtilisateur;
	}

	public String getMdp() {
		return this.mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getNumero() {
		return this.numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getPrenom() {
		return this.prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getSalt() {
		return this.salt;
	}

	public void setSalt(String salt) {
		this.salt = salt;
	}

}