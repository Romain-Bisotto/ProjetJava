package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the offre database table.
 * 
 */
@Entity
@NamedQuery(name="Offre.findAll", query="SELECT o FROM Offre o")
public class Offre implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int IDOffre;

	@Temporal(TemporalType.DATE)
	private Date dateCreation;

	private String etat;

	private int ID_Bien;

	private int ID_Utilisateur;

	private String image;

	private String libelleCourt;

	private String libelleLong;

	private String reference;

	private String typeOffre;

	public Offre() {
	}

	public int getIDOffre() {
		return this.IDOffre;
	}

	public void setIDOffre(int IDOffre) {
		this.IDOffre = IDOffre;
	}

	public Date getDateCreation() {
		return this.dateCreation;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	public String getEtat() {
		return this.etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public int getID_Bien() {
		return this.ID_Bien;
	}

	public void setID_Bien(int ID_Bien) {
		this.ID_Bien = ID_Bien;
	}

	public int getID_Utilisateur() {
		return this.ID_Utilisateur;
	}

	public void setID_Utilisateur(int ID_Utilisateur) {
		this.ID_Utilisateur = ID_Utilisateur;
	}

	public String getImage() {
		return this.image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getLibelleCourt() {
		return this.libelleCourt;
	}

	public void setLibelleCourt(String libelleCourt) {
		this.libelleCourt = libelleCourt;
	}

	public String getLibelleLong() {
		return this.libelleLong;
	}

	public void setLibelleLong(String libelleLong) {
		this.libelleLong = libelleLong;
	}

	public String getReference() {
		return this.reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getTypeOffre() {
		return this.typeOffre;
	}

	public void setTypeOffre(String typeOffre) {
		this.typeOffre = typeOffre;
	}

}