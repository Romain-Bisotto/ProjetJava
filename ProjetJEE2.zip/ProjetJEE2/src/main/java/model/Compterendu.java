package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the compterendu database table.
 * 
 */
@Entity
@NamedQuery(name="Compterendu.findAll", query="SELECT c FROM Compterendu c")
public class Compterendu implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int IDCompteRendu;

	@Temporal(TemporalType.DATE)
	private Date date;

	private int IDOffre;

	private String liIbelle;

	public Compterendu() {
	}

	public int getIDCompteRendu() {
		return this.IDCompteRendu;
	}

	public void setIDCompteRendu(int IDCompteRendu) {
		this.IDCompteRendu = IDCompteRendu;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getIDOffre() {
		return this.IDOffre;
	}

	public void setIDOffre(int IDOffre) {
		this.IDOffre = IDOffre;
	}

	public String getLiIbelle() {
		return this.liIbelle;
	}

	public void setLiIbelle(String liIbelle) {
		this.liIbelle = liIbelle;
	}

}