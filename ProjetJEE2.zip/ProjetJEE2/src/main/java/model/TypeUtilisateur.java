package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the typeutilisateur database table.
 * 
 */
@Entity
@NamedQuery(name="TypeUtilisateur.findAll", query="SELECT t FROM TypeUtilisateur t")
public class TypeUtilisateur implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int IDTypeUtilisateur;

	private String description;

	private String LIbelle;

	public TypeUtilisateur() {
	}

	public int getIDTypeUtilisateur() {
		return this.IDTypeUtilisateur;
	}

	public void setIDTypeUtilisateur(int IDTypeUtilisateur) {
		this.IDTypeUtilisateur = IDTypeUtilisateur;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLIbelle() {
		return this.LIbelle;
	}

	public void setLIbelle(String LIbelle) {
		this.LIbelle = LIbelle;
	}

}