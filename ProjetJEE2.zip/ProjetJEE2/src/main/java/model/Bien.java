package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the bien database table.
 * 
 */
@Entity
@NamedQuery(name="Bien.findAll", query="SELECT b FROM Bien b")
public class Bien implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int ID_Bien;

	private String adresseProprietaire;

	private String arrondissement;

	private String commune;

	private String cp;

	private String description;

	private String etage;

	private int IDOffre;

	private String mailProprietaire;

	private int nbPieces;

	private String nomProprietaire;

	private int numDept;

	private String numeroTelProprietaire;

	private byte parking;

	private String prenomProprietaire;

	private float prixBien;

	private String quartier;

	private String surface;

	private String typeAccesInternet;

	private String typeBien;

	private String typeChauffage;

	private String typeEauChaude;

	public Bien() {
	}

	public int getID_Bien() {
		return this.ID_Bien;
	}

	public void setID_Bien(int ID_Bien) {
		this.ID_Bien = ID_Bien;
	}

	public String getAdresseProprietaire() {
		return this.adresseProprietaire;
	}

	public void setAdresseProprietaire(String adresseProprietaire) {
		this.adresseProprietaire = adresseProprietaire;
	}

	public String getArrondissement() {
		return this.arrondissement;
	}

	public void setArrondissement(String arrondissement) {
		this.arrondissement = arrondissement;
	}

	public String getCommune() {
		return this.commune;
	}

	public void setCommune(String commune) {
		this.commune = commune;
	}

	public String getCp() {
		return this.cp;
	}

	public void setCp(String cp) {
		this.cp = cp;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEtage() {
		return this.etage;
	}

	public void setEtage(String etage) {
		this.etage = etage;
	}

	public int getIDOffre() {
		return this.IDOffre;
	}

	public void setIDOffre(int IDOffre) {
		this.IDOffre = IDOffre;
	}

	public String getMailProprietaire() {
		return this.mailProprietaire;
	}

	public void setMailProprietaire(String mailProprietaire) {
		this.mailProprietaire = mailProprietaire;
	}

	public int getNbPieces() {
		return this.nbPieces;
	}

	public void setNbPieces(int nbPieces) {
		this.nbPieces = nbPieces;
	}

	public String getNomProprietaire() {
		return this.nomProprietaire;
	}

	public void setNomProprietaire(String nomProprietaire) {
		this.nomProprietaire = nomProprietaire;
	}

	public int getNumDept() {
		return this.numDept;
	}

	public void setNumDept(int numDept) {
		this.numDept = numDept;
	}

	public String getNumeroTelProprietaire() {
		return this.numeroTelProprietaire;
	}

	public void setNumeroTelProprietaire(String numeroTelProprietaire) {
		this.numeroTelProprietaire = numeroTelProprietaire;
	}

	public byte getParking() {
		return this.parking;
	}

	public void setParking(byte parking) {
		this.parking = parking;
	}

	public String getPrenomProprietaire() {
		return this.prenomProprietaire;
	}

	public void setPrenomProprietaire(String prenomProprietaire) {
		this.prenomProprietaire = prenomProprietaire;
	}

	public float getPrixBien() {
		return this.prixBien;
	}

	public void setPrixBien(float prixBien) {
		this.prixBien = prixBien;
	}

	public String getQuartier() {
		return this.quartier;
	}

	public void setQuartier(String quartier) {
		this.quartier = quartier;
	}

	public String getSurface() {
		return this.surface;
	}

	public void setSurface(String surface) {
		this.surface = surface;
	}

	public String getTypeAccesInternet() {
		return this.typeAccesInternet;
	}

	public void setTypeAccesInternet(String typeAccesInternet) {
		this.typeAccesInternet = typeAccesInternet;
	}

	public String getTypeBien() {
		return this.typeBien;
	}

	public void setTypeBien(String typeBien) {
		this.typeBien = typeBien;
	}

	public String getTypeChauffage() {
		return this.typeChauffage;
	}

	public void setTypeChauffage(String typeChauffage) {
		this.typeChauffage = typeChauffage;
	}

	public String getTypeEauChaude() {
		return this.typeEauChaude;
	}

	public void setTypeEauChaude(String typeEauChaude) {
		this.typeEauChaude = typeEauChaude;
	}

}