package ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import model.Bien;

@Stateless
public class BienEJB {
	
	@PersistenceUnit
	private EntityManagerFactory emf;

	public Bien findBienById(Long id) {
        EntityManager em = emf.createEntityManager();
        Bien bien = em.find(Bien.class, id);
        em.close();
        return bien;
    }

    public Bien createBien(Bien bien) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(bien);
        em.getTransaction().commit();
        em.close();
        return bien;
    }

    public void updateBien(Bien bien) {
        // Récupération de l'EntityManager
        EntityManager em = emf.createEntityManager();
        // Début de la transaction
        em.getTransaction().begin();
        // Mise à jour de l'objet Bien dans la base de données
        em.merge(bien);
        // Fin de la transaction
        em.getTransaction().commit();
        // Fermeture de l'EntityManager
        em.close();
    }

    public List<Bien> findAllBiens() {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Bien> query = em.createQuery("SELECT b FROM Bien b", Bien.class);
        List<Bien> biens = query.getResultList();
        em.close();
        return biens;
    }

    public void deleteBien(Long id) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Bien bien = em.find(Bien.class, id);
        em.remove(bien);
        em.getTransaction().commit();
        em.close();
    }
    
}
