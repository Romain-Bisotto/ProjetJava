package ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import model.TypeUtilisateur;

@Stateless
public class TypeUtilisateurEJB {
    // ...
		EntityManagerFactory emf;

		    public TypeUtilisateur findTypeUtilisateurById(Long id) {
		        EntityManager em = emf.createEntityManager();
		        TypeUtilisateur typeUtilisateur = em.find(TypeUtilisateur.class, id);
		        em.close();
		        return typeUtilisateur;
		    }

		    public TypeUtilisateur findTypeUtilisateurByLibelle(String libelle) {
		        EntityManager em = emf.createEntityManager();
		        TypedQuery<TypeUtilisateur> query = em.createQuery("SELECT t FROM TypeUtilisateur t WHERE t.libelle = :libelle", TypeUtilisateur.class);
		        query.setParameter("libelle", libelle);
		        TypeUtilisateur typeUtilisateur = query.getSingleResult();
		        em.close();
		        return typeUtilisateur;
		    }

		    public TypeUtilisateur createTypeUtilisateur() {
		        EntityManager em = emf.createEntityManager();
		        em.getTransaction().begin();
		        TypeUtilisateur typeUtilisateur = new TypeUtilisateur();
		        em.persist(typeUtilisateur);
		        em.getTransaction().commit();
		        em.close();
		        return typeUtilisateur;
		    }

		    public void updateTypeUtilisateur(TypeUtilisateur typeUtilisateur) {
		        EntityManager em = emf.createEntityManager();
		        em.getTransaction().begin();
		        em.merge(typeUtilisateur);
		        em.getTransaction().commit();
		        em.close();
		    }

		    public void deleteTypeUtilisateur(Long id) {
		        EntityManager em = emf.createEntityManager();
		        em.getTransaction().begin();
		        TypeUtilisateur typeUtilisateur = em.find(TypeUtilisateur.class, id);
		        em.remove(typeUtilisateur);
		        em.getTransaction().commit();
		        em.close();
		    }


}
