package ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import model.Utilisateur;

@Stateless
public class UtilisateurEJB {
    // ...
	
	EntityManagerFactory emf;

    public Utilisateur findUtilisateurById(Long id) {
        EntityManager em = emf.createEntityManager();
        Utilisateur utilisateur = em.find(Utilisateur.class, id);
        em.close();
        return utilisateur;
    }

    public Utilisateur findUtilisateurByEmail(String email) {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Utilisateur> query = em.createQuery("SELECT u FROM Utilisateur u WHERE u.email = :email", Utilisateur.class);
        query.setParameter("email", email);
        Utilisateur utilisateur = query.getSingleResult();
        em.close();
        System.out.println(utilisateur);
        return utilisateur;
    }

    public Utilisateur createUtilisateur() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Utilisateur utilisateur = new Utilisateur();
        em.persist(utilisateur);
        em.getTransaction().commit();
        em.close();
        return utilisateur;
    }

    public void updateUtilisateur(Utilisateur utilisateur) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.merge(utilisateur);
        em.getTransaction().commit();
        em.close();
    }

    public void deleteUtilisateur(Long id) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Utilisateur utilisateur = em.find(Utilisateur.class, id);
        em.remove(utilisateur);
        em.getTransaction().commit();
        em.close();
    }
}